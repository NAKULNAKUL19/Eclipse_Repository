package com.mvc4.SpringMvcFirstProgram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcFirstProgramApplicationTests {

	@Test
	void contextLoads() {
	}

}
