package com.mvc4.SpringMvcFirstProgram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcFirstProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcFirstProgramApplication.class, args);
	}

}
